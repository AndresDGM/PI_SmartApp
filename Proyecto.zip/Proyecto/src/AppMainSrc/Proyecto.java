package AppMainSrc;/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author Andres Guevara
 * @author Sebastian Morales
 * @author Juan Santiago
 * @author Nicolas Gutierrez
 * @author Miguel
 */
public class Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        App app = new App();
    }
    
}
